# Charity Donation Ledger

A local-first Python application for recording charity donations, searching records, reviewing summaries, and exporting reports.

## What it does

- Add, view, edit and delete donation records
- Validate donor names, causes, dates and positive donation amounts
- Save data locally in both JSON and CSV formats
- Search by keyword and filter by cause/date range
- Calculate totals, averages, largest donation and cause-wise totals
- Export Markdown and plain-text summary reports
- Generate cause distribution and monthly trend charts with Matplotlib
- Import CSV files with column and row validation
- Includes a realistic 40-record sample dataset and automated tests

## Requirements

- Python 3.10 or newer
- Matplotlib (optional; needed only for chart generation)

## Run on Windows

1. Extract the ZIP file.
2. Open the extracted `charity-donation-ledger` folder.
3. In File Explorer, click the address bar, type `cmd`, and press Enter.
4. Create a virtual environment:

   ```powershell
   py -m venv .venv
   .venv\Scripts\activate
   ```

5. Install dependencies:

   ```powershell
   python -m pip install -r requirements.txt
   ```

6. Start the program:

   ```powershell
   python main.py
   ```

If you do not want charts, the rest of the application uses the Python standard library. The app creates `data/donations.json` and `data/donations.csv` automatically.

## Sample data

The `data/sample_donations.csv` and `data/sample_donations.json` files contain 40 sample records. To try them, copy `data/sample_donations.json` to `data/donations.json` before the first run, or choose menu option 9 and import the sample CSV.

## CSV format

The required headers are:

`donation_id,donor,cause,amount,donation_date,payment_method,notes`

Dates must use `YYYY-MM-DD`. Amounts must be positive numbers.

## Run tests

```powershell
python -m unittest discover -s tests -v
```

## Project structure

```text
charity-donation-ledger/
├── charity_ledger/
│   ├── analytics.py
│   ├── charts.py
│   ├── cli.py
│   ├── models.py
│   ├── reports.py
│   └── storage.py
├── data/
│   ├── sample_donations.csv
│   └── sample_donations.json
├── reports/
├── charts/
├── tests/
├── main.py
├── requirements.txt
└── README.md
```

## Design notes

The project deliberately keeps the user interface, data model, persistence, analytics and reporting in separate modules. JSON is the primary reload format and CSV is maintained as a convenient spreadsheet-friendly copy. Writes use a temporary JSON file followed by replacement to reduce the chance of a partially written save.

This is a local demonstration tool, not a payment processor or a regulated charity accounting system. Do not store bank credentials, card numbers or other sensitive payment information in donation notes.
