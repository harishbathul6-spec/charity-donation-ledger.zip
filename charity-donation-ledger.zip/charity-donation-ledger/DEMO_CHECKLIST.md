# 3-minute demo checklist

1. Launch with `python main.py`.
2. Add a donation and deliberately enter an invalid amount once to show validation.
3. View all records and search for a donor or cause.
4. Open the summary dashboard and explain the cause-wise totals.
5. Export reports and generate charts.
6. Exit and relaunch to demonstrate that records persist.
7. Mention that sample records are fictional and are included for demonstration only.

## Questions you should be ready to answer

- Why use JSON and CSV? JSON is convenient for loading structured records; CSV is easy to inspect in spreadsheet software.
- How is invalid data handled? The model validates required fields, numeric limits and ISO dates before saving.
- What happens if the JSON file is malformed? The application reports the issue and attempts to preserve the damaged file with a `.corrupt.json` suffix.
- How can the project be extended? Add donor profiles, authentication, a GUI, database storage, or verified payment integration.
