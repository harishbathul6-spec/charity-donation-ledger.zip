"""Menu-driven command-line application."""
from datetime import date
from pathlib import Path
from uuid import uuid4
from .models import Donation
from .storage import DonationStore
from .analytics import summarize, search_donations
from .reports import export_reports
from .charts import create_charts


def ask(prompt: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    value = input(f"{prompt}{suffix}: ").strip()
    return value or default


def ask_amount() -> float:
    while True:
        raw = input("Donation amount (INR): ").strip().replace(",", "")
        try:
            amount = float(raw)
            if amount <= 0 or amount > 1_000_000_000:
                raise ValueError
            return round(amount, 2)
        except ValueError:
            print("Please enter a number greater than 0 and no more than 1,000,000,000.")


def show_table(records: list[Donation]) -> None:
    if not records:
        print("\nNo donations found.")
        return
    print("\n" + "-" * 100)
    print(f"{'ID':<12} {'DONOR':<20} {'CAUSE':<20} {'AMOUNT (₹)':>14} {'DATE':>12}")
    print("-" * 100)
    for item in records:
        print(f"{item.donation_id[:12]:<12} {item.donor[:20]:<20} {item.cause[:20]:<20} "
              f"{item.amount:>14,.2f} {item.donation_date:>12}")
    print("-" * 100)
    print(f"{len(records)} record(s) shown.")


def add_donation(store, donations):
    print("\nAdd a donation")
    donor = ask("Donor name")
    cause = ask("Cause (Education/Health/Environment/Disaster Relief/Animal Welfare)")
    amount = ask_amount()
    donation_date = ask("Date YYYY-MM-DD", date.today().isoformat())
    payment = ask("Payment method", "UPI")
    notes = ask("Notes (optional)")
    item = Donation(uuid4().hex[:10].upper(), donor, cause, amount, donation_date, payment, notes)
    try:
        item.validate()
    except ValueError as exc:
        print(f"Not saved: {exc}")
        return
    donations.append(item)
    store.save(donations)
    print(f"Saved donation {item.donation_id}.")


def edit_donation(store, donations):
    donation_id = ask("Enter donation ID to edit")
    item = next((row for row in donations if row.donation_id.casefold() == donation_id.casefold()), None)
    if not item:
        print("Donation ID not found.")
        return
    item.donor = ask("Donor", item.donor)
    item.cause = ask("Cause", item.cause)
    item.amount = ask_amount() if ask("Change amount? (y/N)", "N").lower() == "y" else item.amount
    item.donation_date = ask("Date YYYY-MM-DD", item.donation_date)
    item.payment_method = ask("Payment method", item.payment_method)
    item.notes = ask("Notes", item.notes)
    try:
        item.validate()
        store.save(donations)
        print("Donation updated.")
    except ValueError as exc:
        print(f"Update not saved: {exc}")


def delete_donation(store, donations):
    donation_id = ask("Enter donation ID to delete")
    item = next((row for row in donations if row.donation_id.casefold() == donation_id.casefold()), None)
    if not item:
        print("Donation ID not found.")
    elif ask(f"Delete {item.donor}'s ₹{item.amount:,.2f} donation? (y/N)", "N").lower() == "y":
        donations.remove(item)
        store.save(donations)
        print("Donation deleted.")


def run(data_dir: Path | None = None):
    root = Path(__file__).resolve().parent.parent
    store = DonationStore(data_dir or root / "data")
    try:
        donations = store.load()
    except RuntimeError as exc:
        print(f"Storage warning: {exc}")
        donations = []
        store.save(donations)

    while True:
        print("\n" + "=" * 52)
        print("           CHARITY DONATION LEDGER")
        print("=" * 52)
        print("1. Add donation       2. View all donations")
        print("3. Search / filter    4. Edit donation")
        print("5. Delete donation    6. Summary dashboard")
        print("7. Export reports     8. Generate charts")
        print("9. Import CSV         0. Save and exit")
        choice = input("\nChoose an option: ").strip()

        if choice == "1":
            add_donation(store, donations)
        elif choice == "2":
            show_table(donations)
        elif choice == "3":
            keyword = ask("Keyword (donor, cause, notes or ID)")
            cause = ask("Cause filter (optional)")
            start = ask("Start date YYYY-MM-DD (optional)")
            end = ask("End date YYYY-MM-DD (optional)")
            try:
                show_table(search_donations(donations, keyword, cause, start, end))
            except Exception as exc:
                print(f"Search could not be completed: {exc}")
        elif choice == "4":
            edit_donation(store, donations)
        elif choice == "5":
            delete_donation(store, donations)
        elif choice == "6":
            report = summarize(donations)
            print("\nSUMMARY DASHBOARD")
            print(f"Donations recorded : {report['count']}")
            print(f"Total donated     : ₹{report['total']:,.2f}")
            print(f"Average donation  : ₹{report['average']:,.2f}")
            print(f"Largest donation  : ₹{report['largest']:,.2f}")
            print(f"Leading cause     : {report['top_cause']}")
            print("\nCause-wise totals:")
            for cause, amount in report["by_cause"].items():
                print(f"  {cause:<24} ₹{amount:,.2f}")
        elif choice == "7":
            paths = export_reports(donations, root / "reports")
            print("Reports created:")
            for path in paths:
                print(f"  {path}")
        elif choice == "8":
            try:
                paths = create_charts(donations, root / "charts")
                print("Charts created:" if paths else "Add donations first to create charts.")
                for path in paths:
                    print(f"  {path}")
            except RuntimeError as exc:
                print(exc)
        elif choice == "9":
            path = Path(ask("Path to CSV file"))
            try:
                imported = store.import_csv(path, save=False)
                existing = {item.donation_id for item in donations}
                if any(item.donation_id in existing for item in imported):
                    raise ValueError("One or more donation IDs already exist.")
                donations.extend(imported)
                store.save(donations)
                print(f"Imported {len(imported)} donation(s).")
            except (OSError, ValueError) as exc:
                print(f"Import failed: {exc}")
        elif choice == "0":
            store.save(donations)
            print("All changes saved. Thank you for supporting good causes!")
            break
        else:
            print("Please choose a valid menu option (0-9).")
