"""Donation domain model and validation rules."""
from dataclasses import dataclass, asdict
from datetime import date
from decimal import Decimal, InvalidOperation
from typing import Any


@dataclass
class Donation:
    donation_id: str
    donor: str
    cause: str
    amount: float
    donation_date: str
    payment_method: str = "Other"
    notes: str = ""

    def validate(self) -> None:
        if not self.donation_id.strip():
            raise ValueError("Donation ID cannot be blank.")
        if not self.donor.strip():
            raise ValueError("Donor name cannot be blank.")
        if not self.cause.strip():
            raise ValueError("Cause cannot be blank.")
        try:
            value = Decimal(str(self.amount))
        except (InvalidOperation, TypeError):
            raise ValueError("Amount must be a valid number.") from None
        if not value.is_finite() or value <= 0 or value > Decimal("1000000000"):
            raise ValueError("Amount must be greater than 0 and at most 1,000,000,000.")
        try:
            date.fromisoformat(self.donation_date)
        except (TypeError, ValueError):
            raise ValueError("Date must use YYYY-MM-DD format.") from None
        self.donor = self.donor.strip()
        self.cause = self.cause.strip()
        self.payment_method = self.payment_method.strip() or "Other"
        self.notes = self.notes.strip()
        self.amount = round(float(value), 2)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "Donation":
        item = cls(
            donation_id=str(raw.get("donation_id", "")),
            donor=str(raw.get("donor", "")),
            cause=str(raw.get("cause", "")),
            amount=float(raw.get("amount", 0)),
            donation_date=str(raw.get("donation_date", "")),
            payment_method=str(raw.get("payment_method", "Other")),
            notes=str(raw.get("notes", "")),
        )
        item.validate()
        return item

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
