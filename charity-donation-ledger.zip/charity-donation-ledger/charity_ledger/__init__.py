"""Charity Donation Ledger package."""
__version__ = "1.0.0"
