"""Optional Matplotlib chart generation."""
from pathlib import Path
from .analytics import summarize, monthly_totals


def create_charts(donations, output_dir: Path) -> list[Path]:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise RuntimeError("Matplotlib is not installed. Run: pip install -r requirements.txt") from exc

    output_dir.mkdir(parents=True, exist_ok=True)
    created = []
    summary = summarize(donations)
    if summary["by_cause"]:
        fig, ax = plt.subplots(figsize=(9, 5))
        labels = list(summary["by_cause"])
        values = list(summary["by_cause"].values())
        ax.bar(labels, values)
        ax.set_title("Donations by Cause")
        ax.set_ylabel("Amount (INR)")
        ax.tick_params(axis="x", rotation=25)
        fig.tight_layout()
        path = output_dir / "donations_by_cause.png"
        fig.savefig(path, dpi=150)
        plt.close(fig)
        created.append(path)

    monthly = monthly_totals(donations)
    if monthly:
        fig, ax = plt.subplots(figsize=(9, 5))
        ax.plot(list(monthly), list(monthly.values()), marker="o")
        ax.set_title("Monthly Donation Trend")
        ax.set_ylabel("Amount (INR)")
        ax.set_xlabel("Month")
        ax.tick_params(axis="x", rotation=25)
        fig.tight_layout()
        path = output_dir / "monthly_donation_trend.png"
        fig.savefig(path, dpi=150)
        plt.close(fig)
        created.append(path)
    return created
