"""Donation summaries and query helpers."""
from collections import defaultdict
from datetime import date, timedelta
from statistics import mean
from .models import Donation


def summarize(donations: list[Donation]) -> dict:
    total = sum(item.amount for item in donations)
    causes = defaultdict(float)
    methods = defaultdict(int)
    for item in donations:
        causes[item.cause] += item.amount
        methods[item.payment_method] += 1
    top_cause = max(causes, key=causes.get) if causes else "N/A"
    return {
        "count": len(donations),
        "total": round(total, 2),
        "average": round(mean(item.amount for item in donations), 2) if donations else 0.0,
        "largest": max((item.amount for item in donations), default=0.0),
        "top_cause": top_cause,
        "by_cause": dict(sorted(causes.items(), key=lambda pair: pair[1], reverse=True)),
        "by_payment_method": dict(sorted(methods.items())),
    }


def search_donations(donations: list[Donation], keyword: str = "", cause: str = "",
                     start_date: str = "", end_date: str = "") -> list[Donation]:
    keyword, cause = keyword.casefold().strip(), cause.casefold().strip()
    results = []
    for item in donations:
        searchable = f"{item.donor} {item.cause} {item.notes} {item.donation_id}".casefold()
        if keyword and keyword not in searchable:
            continue
        if cause and cause not in item.cause.casefold():
            continue
        if start_date and item.donation_date < start_date:
            continue
        if end_date and item.donation_date > end_date:
            continue
        results.append(item)
    return sorted(results, key=lambda item: (item.donation_date, item.donation_id), reverse=True)


def monthly_totals(donations: list[Donation]) -> dict[str, float]:
    totals = defaultdict(float)
    for item in donations:
        month = item.donation_date[:7]
        totals[month] += item.amount
    return dict(sorted((key, round(value, 2)) for key, value in totals.items()))
