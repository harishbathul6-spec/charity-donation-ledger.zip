"""Local JSON and CSV persistence."""
import csv
import json
from pathlib import Path
from typing import Iterable
from .models import Donation

FIELDS = ["donation_id", "donor", "cause", "amount", "donation_date", "payment_method", "notes"]


class DonationStore:
    def __init__(self, data_dir: Path):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.json_path = self.data_dir / "donations.json"
        self.csv_path = self.data_dir / "donations.csv"

    def load(self) -> list[Donation]:
        if not self.json_path.exists():
            if self.csv_path.exists():
                return self.import_csv(self.csv_path, save=False)
            self.save([])
            return []
        try:
            with self.json_path.open("r", encoding="utf-8") as handle:
                raw = json.load(handle)
            if not isinstance(raw, list):
                raise ValueError("The JSON data must contain a list of donations.")
            records = [Donation.from_dict(row) for row in raw]
            return records
        except (json.JSONDecodeError, OSError, TypeError, ValueError) as exc:
            backup = self.json_path.with_suffix(".corrupt.json")
            try:
                self.json_path.replace(backup)
            except OSError:
                pass
            raise RuntimeError(
                f"Could not read donation data ({exc}). A clean file will be created; "
                f"the original is preserved when possible at {backup.name}."
            ) from exc

    def save(self, donations: Iterable[Donation]) -> None:
        records = list(donations)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        temp_path = self.json_path.with_suffix(".tmp")
        with temp_path.open("w", encoding="utf-8") as handle:
            json.dump([item.to_dict() for item in records], handle, indent=2, ensure_ascii=False)
        temp_path.replace(self.json_path)
        with self.csv_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=FIELDS)
            writer.writeheader()
            writer.writerows(item.to_dict() for item in records)

    def import_csv(self, path: Path, save: bool = True) -> list[Donation]:
        imported, errors = [], []
        with Path(path).open("r", newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            missing = set(FIELDS) - set(reader.fieldnames or [])
            if missing:
                raise ValueError("CSV is missing required columns: " + ", ".join(sorted(missing)))
            for line_no, row in enumerate(reader, start=2):
                try:
                    imported.append(Donation.from_dict(row))
                except (ValueError, TypeError) as exc:
                    errors.append(f"Line {line_no}: {exc}")
        if errors:
            detail = "\n".join(errors[:10])
            raise ValueError(f"{len(errors)} row(s) were invalid; no records imported.\n{detail}")
        if save:
            existing = self.load()
            known = {item.donation_id for item in existing}
            duplicates = [item.donation_id for item in imported if item.donation_id in known]
            if duplicates:
                raise ValueError("Duplicate donation ID(s): " + ", ".join(duplicates[:10]))
            self.save(existing + imported)
        return imported
