"""Human-readable report exports."""
from datetime import datetime
from pathlib import Path
from .analytics import summarize, monthly_totals


def build_report(donations) -> str:
    summary = summarize(donations)
    lines = [
        "# Charity Donation Ledger — Summary Report",
        "",
        f"Generated: {datetime.now().astimezone().strftime('%Y-%m-%d %H:%M %Z')}",
        "",
        "## Overview",
        f"- Number of donations: {summary['count']}",
        f"- Total donated: ₹{summary['total']:,.2f}",
        f"- Average donation: ₹{summary['average']:,.2f}",
        f"- Largest donation: ₹{summary['largest']:,.2f}",
        f"- Leading cause: {summary['top_cause']}",
        "",
        "## Donations by cause",
        "| Cause | Amount |",
        "|---|---:|",
    ]
    for cause, amount in summary["by_cause"].items():
        lines.append(f"| {cause} | ₹{amount:,.2f} |")
    lines += ["", "## Monthly trend", "| Month | Amount |", "|---|---:|"]
    for month, amount in monthly_totals(donations).items():
        lines.append(f"| {month} | ₹{amount:,.2f} |")
    lines += ["", "## Donation register", "| ID | Donor | Cause | Amount | Date |",
              "|---|---|---|---:|---|"]
    for item in sorted(donations, key=lambda row: row.donation_date, reverse=True):
        safe_donor = item.donor.replace("|", "\\|")
        safe_cause = item.cause.replace("|", "\\|")
        lines.append(f"| {item.donation_id} | {safe_donor} | {safe_cause} | ₹{item.amount:,.2f} | {item.donation_date} |")
    return "\n".join(lines) + "\n"


def export_reports(donations, reports_dir: Path) -> list[Path]:
    reports_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    content = build_report(donations)
    md = reports_dir / f"donation_report_{stamp}.md"
    txt = reports_dir / f"donation_report_{stamp}.txt"
    md.write_text(content, encoding="utf-8")
    txt.write_text(content.replace("#", "").replace("|", " | "), encoding="utf-8")
    return [md, txt]
