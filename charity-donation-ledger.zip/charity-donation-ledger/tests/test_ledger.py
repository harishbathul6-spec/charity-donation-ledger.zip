import tempfile
import unittest
from pathlib import Path

from charity_ledger.models import Donation
from charity_ledger.analytics import summarize, search_donations
from charity_ledger.storage import DonationStore


def sample():
    return Donation("D001", "Asha Rao", "Education", 500.0, "2026-01-15", "UPI", "Books fund")


class DonationModelTests(unittest.TestCase):
    def test_valid_donation(self):
        item = sample()
        item.validate()
        self.assertEqual(item.amount, 500.0)

    def test_rejects_non_positive_amount(self):
        item = sample()
        item.amount = 0
        with self.assertRaises(ValueError):
            item.validate()

    def test_rejects_invalid_date(self):
        item = sample()
        item.donation_date = "15-01-2026"
        with self.assertRaises(ValueError):
            item.validate()


class AnalyticsTests(unittest.TestCase):
    def test_summary(self):
        result = summarize([sample()])
        self.assertEqual(result["count"], 1)
        self.assertEqual(result["total"], 500.0)
        self.assertEqual(result["top_cause"], "Education")

    def test_search(self):
        results = search_donations([sample()], keyword="asha", cause="educ")
        self.assertEqual(len(results), 1)


class StorageTests(unittest.TestCase):
    def test_json_round_trip(self):
        with tempfile.TemporaryDirectory() as folder:
            store = DonationStore(Path(folder))
            store.save([sample()])
            loaded = store.load()
            self.assertEqual(len(loaded), 1)
            self.assertEqual(loaded[0].donor, "Asha Rao")
            self.assertTrue(store.csv_path.exists())


if __name__ == "__main__":
    unittest.main()
