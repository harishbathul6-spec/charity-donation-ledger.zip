"""Launch the Charity Donation Ledger."""
from charity_ledger.cli import run

if __name__ == "__main__":
    run()
